#################################################################
##           Open Source GIS - Large Wood in Rivers            ##
##                      25/11/2025                             ##
##                  Creating a ShinyApp                        ##
##                         App.R                               ##
##        code by Chris Townshend (ct728@exeter.ac.uk)         ##
#################################################################

# Install packages

install.packages("shiny")
install.packages("leaflet")
install.packages("sf")
install.packages("raster")
install.packages("ggplot2")
install.packages("ggiraph")
install.packages("RColorBrewer")
install.packages("terra")
install.packages("leafem")
install..packages("dbscan")

# Load packages ----
library(shiny)
library(leaflet)
library(sf)
library(raster)
library(ggplot2)
library(ggiraph)
library(RColorBrewer)
library(terra)
library(leafem)
library(dbscan)

options(shiny.maxRequestSize = 1000 * 1024^2)

# Run global script containing all your relevant data ----
source("textcolorpurpleGlobal.R")

# Define UI for visualisation ----
source("textcolorpurpleUI.R")

ui <- navbarPage("Large wood in the River Torridge", id = 'nav',
                 tabPanel("map", 
                          div(class="outer",
                              leafletOutput("map", height = "calc(100vh - 70px)")
                          )
                 )
)

# Define the server that performs all necessary operations ----
server <- function(input, output, session){
  source("textcolorpurpleServer.R", local = TRUE)
}

# Run the application ----
shinyApp(ui, server)
