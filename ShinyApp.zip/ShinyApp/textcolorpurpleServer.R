#################################################################
##           Open Source GIS - Large Wood in Rivers            ##
##                      25/11/2025                             ##
##                  Creating a ShinyApp                        ##
##                       Server.R                              ##
##        code by Chris Townshend (ct728@exeter.ac.uk)         ##
#################################################################

# S1 Render leaflet map ----

# Leaflet map output
output$map <- renderLeaflet({
  
  leaflet() %>% 
    
    setView(lng=-4.163132, lat=50.949815, zoom=11.3) %>%
    addProviderTiles(providers$OpenStreetMap, group = "Open Street Map") %>%
    addPolylines(data = river, fillColor = "blue", color = "blue", weight = 2, opacity = 0.5, group = "River") %>%
    addRasterImage(heatmap, colors = pal_heatmap, opacity = 1, group = "Large Wood Heatmap") %>%
    addImageQuery(
      heatmap,
      layerId = "Large Wood Heatmap",
      prefix = "Value: ",
      digits = 2,
      position = "topright",
      type = "mousemove",
      options = queryOptions(position = "topright"),
      group = "Heatmap"
    ) %>%
    addRasterImage(aspect, colors = pal_aspect, opacity = 1, group = "Aspect", maxBytes = 1.5e+7) %>%
    addImageQuery(
      aspect,
      layerId = "Aspect",
      prefix = "Value: ",
      digits = 2,
      position = "topright",
      type = "mousemove",
      options = queryOptions(position = "topright"),
      group = "Aspect") %>%
      addRasterImage(slope, colors = pal_slope, opacity = 1, group = "Slope", maxBytes = 1.5e+7) %>%
      addImageQuery(
        slope,
        layerId = "Slope",
        prefix = "Value: ",
        digits = 2,
        position = "topright",
        type = "mousemove",
        options = queryOptions(position = "topright"),
        group = "Slope"
    )

})

# Add popups for large wood points
observe({
  leafletProxy("map") %>%
    clearMarkers() %>%
    addCircleMarkers(data = lw_points,
                     fillColor = ~pal_LW_points(LW_Type),
                     color = "black",
                     weight = 1, radius = 5, stroke = TRUE, fillOpacity = 1,
                     popup = ~paste("<b>Large Wood Type:</b>", LW_Type, "<br>"),
                     group = "Large Wood Types") %>%
    addCircleMarkers(data = clusters, 
                     fillColor = ~pal_clusters(CLUSTER_ID),
                     color = "black", 
                     weight = 1, radius = 5, stroke = TRUE, fillOpacity = 1,
                     popup = ~paste("<b>Large Wood Type:</b>", LW_Type, "<br>", 
                                    "<b>Cluster Size:</b>", CLUSTER_SI),
                     group = "Large Wood Clusters") %>%
    addCircleMarkers(data = distances, 
                     fillColor = ~pal_distances(Distance_5),
                     color = "black", 
                     weight = 1, radius = 5, stroke = TRUE, fillOpacity = 1,
                     popup = ~paste("<b>Large Wood Type:</b>", LW_Type,"<br>", 
                                    "<b>Downstream Bridge:</b>", BridgeRisk, "<br>", 
                                    "<b>Distance to Bridge (m):</b>", Distance_5),
                     group = "Large Wood Distance from Bridges") %>%
    addMarkers(data = bridges,
               icon = star_icon,
               popup = ~paste("<b>Bridge Name:</b>", Label),
               group = "Bridges") %>%
    addCircleMarkers(data = catchers,
                     fillColor = "purple",
                     color = "black",
                     weight = 1, radius = 10, stroke = TRUE, fillOpacity = 1,
                     popup = ~paste("<b>Bridge:</b>", Bridge),
                     group = "Large Wood Retention Structures") %>%
    addLayersControl(
      overlayGroups = c("River", "Bridges", "Aspect", "Slope", "Large Wood Retention Structures"),
      baseGroups = c("Large Wood Types", "Large Wood Clusters", "Large Wood Distance from Bridges", "Large Wood Heatmap"),
      options = layersControlOptions(collapsed = TRUE)
  )
})

observe({
  
  # Remove any existing legends
  leafletProxy("map") %>% clearControls()
  
  # Get active overlay groups
  active_groups <- input$map_groups
  
  # LEGEND: Large Wood Types
  if ("Large Wood Types" %in% active_groups) {
    leafletProxy("map") %>% 
      addLegend(
        "bottomleft",
        pal = pal_LW_points,
        values = lw_points$LW_Type,
        opacity = 1,
        title = "Large Wood Types"
      )
  }
  if ("Large Wood Clusters" %in% active_groups) {
    leafletProxy("map") %>% 
      addLegend(
        "bottomleft",
        pal = pal_clusters,
        values = clusters$CLUSTER_SI,
        opacity = 1,
        title = "Cluster Size"
      )
  }
  if ("Large Wood Distance from Bridges" %in% active_groups) {
    leafletProxy("map") %>% 
      addLegend(
        "bottomleft",
        pal = pal_distances,
        values = distances$Distance_5,
        opacity = 1,
        title = "Distance to Upstream Bridge (m)"
      )
  }
  if ("Large Wood Heatmap" %in% active_groups) {
    leafletProxy("map") %>% 
      addLegend(
        "bottomleft",
        pal = pal_heatmap,
        values = values(heatmap),
        opacity = 1,
        title = "Heatmap Value"
      )
  }
  if ("Aspect" %in% active_groups) {
    leafletProxy("map") %>% 
      addLegend(
        "bottomleft",
        pal = pal_aspect,
        values = values(aspect),
        opacity = 1,
        title = "Aspect (degrees)"
      )
  }
  if ("Slope" %in% active_groups) {
    leafletProxy("map") %>% 
      addLegend(
        "bottomleft",
        pal = pal_slope,
        values = values(slope),
        opacity = 1,
        title = "Slope (degrees)"
      )
  }
})

