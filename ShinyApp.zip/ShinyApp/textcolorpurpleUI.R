
#################################################################
##           Open Source GIS - Large Wood in Rivers            ##
##                      25/11/2025                             ##
##                  Creating a ShinyApp                        ##
##                         UI.R                                ##
##        code by Chris Townshend (ct728@exeter.ac.uk)         ##
#################################################################


div(class="outer",
    leafletOutput("map", height = "calc(100vh - 70px)")
)
